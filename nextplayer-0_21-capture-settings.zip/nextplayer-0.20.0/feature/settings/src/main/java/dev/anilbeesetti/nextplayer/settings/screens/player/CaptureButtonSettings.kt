package dev.anilbeesetti.nextplayer.settings.screens.player

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.ListItemDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import dev.anilbeesetti.nextplayer.core.ui.CaptureButtonPrefs
import dev.anilbeesetti.nextplayer.core.ui.R
import dev.anilbeesetti.nextplayer.core.ui.components.ClickablePreferenceItem
import dev.anilbeesetti.nextplayer.core.ui.components.ListSectionTitle
import dev.anilbeesetti.nextplayer.core.ui.components.PreferenceSlider
import dev.anilbeesetti.nextplayer.core.ui.components.PreferenceSwitch
import dev.anilbeesetti.nextplayer.core.ui.components.RadioTextButton
import dev.anilbeesetti.nextplayer.core.ui.designsystem.NextIcons
import dev.anilbeesetti.nextplayer.settings.composables.OptionsDialog
import kotlin.math.roundToInt

private enum class CaptureSide { LEFT, RIGHT, CUSTOM }

private fun sideOf(x: Float) = when {
    x <= 0.15f -> CaptureSide.LEFT
    x >= 0.85f -> CaptureSide.RIGHT
    else -> CaptureSide.CUSTOM
}

/**
 * Settings section for the capture (screenshot) button:
 * on/off, left/right position, size, transparency and reset.
 * The button can still be dragged anywhere in the player; this just gives quick presets.
 */
@Composable
fun CaptureButtonSettings() {
    val context = LocalContext.current
    val prefs = remember { CaptureButtonPrefs.prefs(context) }

    var enabled by remember { mutableStateOf(CaptureButtonPrefs.isEnabled(prefs)) }
    var x by remember { mutableFloatStateOf(CaptureButtonPrefs.x(prefs)) }
    var size by remember { mutableFloatStateOf(CaptureButtonPrefs.size(prefs)) }
    var opacity by remember { mutableFloatStateOf(CaptureButtonPrefs.opacity(prefs)) }
    var showPositionDialog by remember { mutableStateOf(false) }

    ListSectionTitle(text = stringResource(id = R.string.capture_button))
    Column(verticalArrangement = Arrangement.spacedBy(ListItemDefaults.SegmentedGap)) {
        PreferenceSwitch(
            title = stringResource(id = R.string.capture_button_show),
            description = stringResource(id = R.string.capture_button_show_description),
            icon = NextIcons.Image,
            isChecked = enabled,
            onClick = {
                enabled = !enabled
                CaptureButtonPrefs.setEnabled(prefs, enabled)
            },
            isFirstItem = true,
        )
        ClickablePreferenceItem(
            title = stringResource(id = R.string.capture_button_position),
            description = stringResource(
                id = when (sideOf(x)) {
                    CaptureSide.LEFT -> R.string.control_buttons_alignment_left
                    CaptureSide.RIGHT -> R.string.control_buttons_alignment_right
                    CaptureSide.CUSTOM -> R.string.capture_button_position_custom
                },
            ),
            icon = NextIcons.Selection,
            enabled = enabled,
            onClick = { showPositionDialog = true },
        )
        PreferenceSlider(
            title = stringResource(id = R.string.size),
            description = "${size.roundToInt()} dp",
            icon = NextIcons.Image,
            enabled = enabled,
            value = size,
            valueRange = CaptureButtonPrefs.MIN_SIZE_DP..CaptureButtonPrefs.MAX_SIZE_DP,
            onValueChange = { size = it },
            onValueChangeFinished = { CaptureButtonPrefs.setSize(prefs, size) },
        )
        PreferenceSlider(
            title = stringResource(id = R.string.capture_button_opacity),
            description = "${(opacity * 100).roundToInt()}%",
            icon = NextIcons.Brightness,
            enabled = enabled,
            value = opacity,
            valueRange = 0.1f..1f,
            onValueChange = { opacity = it },
            onValueChangeFinished = { CaptureButtonPrefs.setOpacity(prefs, opacity) },
        )
        ClickablePreferenceItem(
            title = stringResource(id = R.string.reset),
            description = stringResource(id = R.string.capture_button_reset_description),
            icon = NextIcons.History,
            onClick = {
                CaptureButtonPrefs.reset(prefs)
                enabled = CaptureButtonPrefs.DEFAULT_ENABLED
                x = CaptureButtonPrefs.DEFAULT_X
                size = CaptureButtonPrefs.DEFAULT_SIZE_DP
                opacity = CaptureButtonPrefs.DEFAULT_OPACITY
            },
            isLastItem = true,
        )
    }

    if (showPositionDialog) {
        OptionsDialog(
            text = stringResource(id = R.string.capture_button_position),
            onDismissClick = { showPositionDialog = false },
        ) {
            items(listOf(CaptureSide.LEFT, CaptureSide.RIGHT)) { side ->
                RadioTextButton(
                    text = stringResource(
                        id = if (side == CaptureSide.LEFT) {
                            R.string.control_buttons_alignment_left
                        } else {
                            R.string.control_buttons_alignment_right
                        },
                    ),
                    selected = sideOf(x) == side,
                    onClick = {
                        x = if (side == CaptureSide.LEFT) {
                            CaptureButtonPrefs.LEFT_X
                        } else {
                            CaptureButtonPrefs.RIGHT_X
                        }
                        CaptureButtonPrefs.setX(prefs, x)
                        showPositionDialog = false
                    },
                )
            }
        }
    }
}
