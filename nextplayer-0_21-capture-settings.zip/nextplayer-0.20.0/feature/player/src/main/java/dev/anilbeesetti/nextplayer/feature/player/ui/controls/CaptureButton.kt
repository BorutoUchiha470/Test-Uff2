package dev.anilbeesetti.nextplayer.feature.player.ui.controls

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.media3.common.Player
import dev.anilbeesetti.nextplayer.core.ui.CaptureButtonPrefs
import dev.anilbeesetti.nextplayer.core.ui.R
import dev.anilbeesetti.nextplayer.feature.player.utils.saveCurrentFrame
import kotlin.math.roundToInt
import kotlinx.coroutines.launch


/**
 * A floating screen-capture button.
 * Tap: save the current frame. Drag: move it anywhere. Long-press: resize or reset it.
 * Position and size are remembered.
 */
@Composable
fun CaptureButton(
    player: Player?,
    modifier: Modifier = Modifier,
) {
    val context = LocalContext.current
    val density = LocalDensity.current
    val scope = rememberCoroutineScope()
    val prefs = remember { CaptureButtonPrefs.prefs(context) }

    // Position is stored as a fraction of the free space, so it also fits after rotating the phone.
    val fractionX = remember { mutableFloatStateOf(CaptureButtonPrefs.x(prefs)) }
    val fractionY = remember { mutableFloatStateOf(CaptureButtonPrefs.y(prefs)) }
    val sizeDp = remember { mutableFloatStateOf(CaptureButtonPrefs.size(prefs)) }
    val opacity = remember { CaptureButtonPrefs.opacity(prefs) }
    var showSettings by remember { mutableStateOf(false) }

    // Hidden completely when turned off in Settings > Player > Capture button.
    if (!CaptureButtonPrefs.isEnabled(prefs)) return

    val save = {
        CaptureButtonPrefs.setPosition(prefs, fractionX.floatValue, fractionY.floatValue)
        CaptureButtonPrefs.setSize(prefs, sizeDp.floatValue)
    }

    BoxWithConstraints(modifier = modifier.fillMaxSize()) {
        val sizePx = with(density) { sizeDp.floatValue.dp.toPx() }
        val maxX = (with(density) { maxWidth.toPx() } - sizePx).coerceAtLeast(0f)
        val maxY = (with(density) { maxHeight.toPx() } - sizePx).coerceAtLeast(0f)
        val offsetX = fractionX.floatValue.coerceIn(0f, 1f) * maxX
        val offsetY = fractionY.floatValue.coerceIn(0f, 1f) * maxY

        Box(
            modifier = Modifier
                .offset { IntOffset(offsetX.roundToInt(), offsetY.roundToInt()) }
                .size(sizeDp.floatValue.dp)
                .clip(CircleShape)
                .background(Color.Black.copy(alpha = opacity))
                .pointerInput(player) {
                    detectTapGestures(
                        onTap = {
                            scope.launch {
                                val saved = runCatching { saveCurrentFrame(context, player) }
                                    .getOrDefault(false)
                                Toast.makeText(
                                    context,
                                    if (saved) R.string.frame_saved else R.string.frame_capture_failed,
                                    Toast.LENGTH_SHORT,
                                ).show()
                            }
                        },
                        onLongPress = { showSettings = true },
                    )
                }
                .pointerInput(maxX, maxY) {
                    detectDragGestures(
                        onDragEnd = { save() },
                        onDragCancel = { save() },
                        onDrag = { change, dragAmount ->
                            change.consume()
                            if (maxX > 0f) {
                                fractionX.floatValue =
                                    ((fractionX.floatValue * maxX + dragAmount.x) / maxX).coerceIn(0f, 1f)
                            }
                            if (maxY > 0f) {
                                fractionY.floatValue =
                                    ((fractionY.floatValue * maxY + dragAmount.y) / maxY).coerceIn(0f, 1f)
                            }
                        },
                    )
                },
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                painter = painterResource(R.drawable.ic_capture),
                contentDescription = stringResource(R.string.capture_frame),
                tint = Color.White,
                modifier = Modifier.size((sizeDp.floatValue * 0.5f).dp),
            )
        }
    }

    if (showSettings) {
        AlertDialog(
            onDismissRequest = {
                save()
                showSettings = false
            },
            title = { Text(text = stringResource(R.string.capture_frame)) },
            text = {
                Column {
                    Text(text = stringResource(R.string.capture_button_hint))
                    Text(text = stringResource(R.string.size))
                    Slider(
                        value = sizeDp.floatValue,
                        onValueChange = { sizeDp.floatValue = it },
                        onValueChangeFinished = { save() },
                        valueRange = CaptureButtonPrefs.MIN_SIZE_DP..CaptureButtonPrefs.MAX_SIZE_DP,
                    )
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        save()
                        showSettings = false
                    },
                ) {
                    Text(text = stringResource(R.string.done))
                }
            },
            dismissButton = {
                TextButton(
                    onClick = {
                        fractionX.floatValue = CaptureButtonPrefs.DEFAULT_X
                        fractionY.floatValue = CaptureButtonPrefs.DEFAULT_Y
                        sizeDp.floatValue = CaptureButtonPrefs.DEFAULT_SIZE_DP
                        save()
                    },
                ) {
                    Text(text = stringResource(R.string.reset))
                }
            },
        )
    }
}
