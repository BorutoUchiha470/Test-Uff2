package dev.anilbeesetti.nextplayer.feature.player.utils

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.media3.common.Player
import java.io.File
import java.io.FileOutputStream
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

private const val MICROS_PER_MILLI = 1_000L
private const val JPEG_QUALITY = 95
private const val ALBUM_NAME = "NextPlayer"

/**
 * Saves the frame that is on screen right now as a full-resolution JPEG in Pictures/NextPlayer.
 * Returns true when the picture was saved.
 */
suspend fun saveCurrentFrame(context: Context, player: Player?): Boolean {
    // Media3 players must be read on the main thread, so do it before switching to IO.
    val mediaItem = player?.currentMediaItem ?: return false
    val uri = mediaItem.localConfiguration?.uri ?: return false
    val positionUs = player.currentPosition * MICROS_PER_MILLI

    return withContext(Dispatchers.IO) {
        val retriever = MediaMetadataRetriever()
        try {
            when (uri.scheme) {
                "http", "https" -> retriever.setDataSource(uri.toString(), HashMap<String, String>())
                else -> retriever.setDataSource(context, uri)
            }
            val frame = retriever.getFrameAtTime(positionUs, MediaMetadataRetriever.OPTION_CLOSEST)
            if (frame == null) false else saveBitmap(context, frame)
        } catch (e: Throwable) {
            false
        } finally {
            runCatching { retriever.release() }
        }
    }
}

private fun saveBitmap(context: Context, bitmap: Bitmap): Boolean {
    val fileName = "NextPlayer_${System.currentTimeMillis()}.jpg"
    return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, fileName)
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            put(MediaStore.Images.Media.RELATIVE_PATH, "${Environment.DIRECTORY_PICTURES}/$ALBUM_NAME")
            put(MediaStore.Images.Media.IS_PENDING, 1)
        }
        val resolver = context.contentResolver
        val target = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
            ?: return false
        val written = resolver.openOutputStream(target)?.use { out ->
            bitmap.compress(Bitmap.CompressFormat.JPEG, JPEG_QUALITY, out)
        } ?: false
        values.clear()
        values.put(MediaStore.Images.Media.IS_PENDING, 0)
        resolver.update(target, values, null, null)
        written
    } else {
        // Android 8 and 9: save in the app's own picture folder (no storage permission needed).
        val folder = context.getExternalFilesDir(Environment.DIRECTORY_PICTURES) ?: return false
        FileOutputStream(File(folder, fileName)).use { out ->
            bitmap.compress(Bitmap.CompressFormat.JPEG, JPEG_QUALITY, out)
        }
    }
}
