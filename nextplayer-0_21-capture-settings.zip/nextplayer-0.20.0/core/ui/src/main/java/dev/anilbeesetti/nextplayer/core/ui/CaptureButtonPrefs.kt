package dev.anilbeesetti.nextplayer.core.ui

import android.content.Context
import android.content.SharedPreferences

/**
 * Stores the capture (screenshot) button settings.
 * Shared by the player (which draws the button) and the settings screen.
 * X/Y are fractions (0..1) of the free screen space, so they survive rotation.
 */
object CaptureButtonPrefs {
    private const val PREFS_NAME = "capture_button"
    private const val KEY_ENABLED = "enabled"
    private const val KEY_X = "x"
    private const val KEY_Y = "y"
    private const val KEY_SIZE = "size"
    private const val KEY_OPACITY = "opacity"

    const val DEFAULT_ENABLED = true
    const val DEFAULT_X = 0.92f
    const val DEFAULT_Y = 0.55f
    const val DEFAULT_SIZE_DP = 52f
    const val DEFAULT_OPACITY = 0.5f
    const val MIN_SIZE_DP = 32f
    const val MAX_SIZE_DP = 110f

    /** Fraction used for the "Left" / "Right" presets. */
    const val LEFT_X = 0.04f
    const val RIGHT_X = 0.96f

    fun prefs(context: Context): SharedPreferences =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun isEnabled(p: SharedPreferences) = p.getBoolean(KEY_ENABLED, DEFAULT_ENABLED)
    fun x(p: SharedPreferences) = p.getFloat(KEY_X, DEFAULT_X)
    fun y(p: SharedPreferences) = p.getFloat(KEY_Y, DEFAULT_Y)
    fun size(p: SharedPreferences) = p.getFloat(KEY_SIZE, DEFAULT_SIZE_DP)
    fun opacity(p: SharedPreferences) = p.getFloat(KEY_OPACITY, DEFAULT_OPACITY)

    fun setEnabled(p: SharedPreferences, value: Boolean) = p.edit().putBoolean(KEY_ENABLED, value).apply()
    fun setX(p: SharedPreferences, value: Float) = p.edit().putFloat(KEY_X, value).apply()
    fun setSize(p: SharedPreferences, value: Float) = p.edit().putFloat(KEY_SIZE, value).apply()
    fun setOpacity(p: SharedPreferences, value: Float) = p.edit().putFloat(KEY_OPACITY, value).apply()

    fun setPosition(p: SharedPreferences, x: Float, y: Float) =
        p.edit().putFloat(KEY_X, x).putFloat(KEY_Y, y).apply()

    fun reset(p: SharedPreferences) = p.edit()
        .putBoolean(KEY_ENABLED, DEFAULT_ENABLED)
        .putFloat(KEY_X, DEFAULT_X)
        .putFloat(KEY_Y, DEFAULT_Y)
        .putFloat(KEY_SIZE, DEFAULT_SIZE_DP)
        .putFloat(KEY_OPACITY, DEFAULT_OPACITY)
        .apply()
}
