package dev.anilbeesetti.nextplayer.feature.more.navigation

import androidx.compose.runtime.SideEffect
import androidx.navigation3.runtime.EntryProviderScope
import androidx.navigation3.runtime.NavBackStack
import androidx.navigation3.runtime.NavKey
import dev.anilbeesetti.nextplayer.feature.more.screens.history.HistoryScreen
import dev.anilbeesetti.nextplayer.feature.more.screens.history.HistoryViewModel
import dev.anilbeesetti.nextplayer.feature.more.screens.more.MoreScreen
import dev.anilbeesetti.nextplayer.feature.more.screens.more.MoreViewModel
import dev.anilbeesetti.nextplayer.feature.more.screens.trash.TrashScreen
import dev.anilbeesetti.nextplayer.feature.more.screens.trash.TrashViewModel
import kotlinx.serialization.Serializable
import org.koin.compose.viewmodel.koinViewModel
import org.koin.core.parameter.parametersOf

@Serializable
object MoreRoute : NavKey

@Serializable
object HistoryRoute : NavKey

@Serializable
object TrashRoute : NavKey

fun EntryProviderScope<NavKey>.moreEntry(
    onHistoryClick: () -> Unit,
    onPlayVideo: (String) -> Unit,
    onSettingsClick: () -> Unit,
    onTrashClick: () -> Unit,
    onVaultClick: () -> Unit,
) {
    entry<MoreRoute> {
        val output = MoreViewModel.Output(
            openHistory = onHistoryClick,
            playVideo = onPlayVideo,
            openSettings = onSettingsClick,
            openTrash = onTrashClick,
            openVault = onVaultClick,
        )
        val viewModel = koinViewModel<MoreViewModel>(
            parameters = { parametersOf(output) },
        )
        SideEffect { viewModel.output = output }
        MoreScreen(viewModel = viewModel)
    }
}

fun EntryProviderScope<NavKey>.historyEntry(
    onNavigateUp: () -> Unit,
    onPlayVideo: (String) -> Unit,
) {
    entry<HistoryRoute> {
        val output = HistoryViewModel.Output(
            navigateUp = onNavigateUp,
            playVideo = onPlayVideo,
        )
        val viewModel = koinViewModel<HistoryViewModel>(
            parameters = { parametersOf(output) },
        )
        SideEffect { viewModel.output = output }
        HistoryScreen(viewModel = viewModel)
    }
}

fun EntryProviderScope<NavKey>.trashEntry(
    onNavigateUp: () -> Unit,
    onPlayVideo: (String) -> Unit,
) {
    entry<TrashRoute> {
        val output = TrashViewModel.Output(
            navigateUp = onNavigateUp,
            playVideo = onPlayVideo,
        )
        val viewModel = koinViewModel<TrashViewModel>(
            parameters = { parametersOf(output) },
        )
        SideEffect { viewModel.output = output }
        TrashScreen(viewModel = viewModel)
    }
}

fun NavBackStack<NavKey>.navigateToMore() {
    add(element = MoreRoute)
}

fun NavBackStack<NavKey>.navigateToHistory() {
    add(element = HistoryRoute)
}

fun NavBackStack<NavKey>.navigateToTrash() {
    add(element = TrashRoute)
}
